package com.ras.autoclicker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    companion object { var current: MainActivity? = null }

    private val GOLD = Color.parseColor("#D4AF37")
    private val IVORY = Color.parseColor("#F5F0E1")
    private val RED = Color.parseColor("#E53935")
    private val GREEN = Color.parseColor("#2ECC71")
    private lateinit var content: LinearLayout
    private var screen = "home"

    private val channels = listOf(
        "CANAL FELCOR" to "https://youtube.com/@felcor?si=h24n3RTS_8o2Ljlu",
        "CANAL comer305" to "https://youtube.com/@comer305?si=XJDEP0JpTCxKhfww",
        "CANAL DYLANFUT" to "https://youtube.com/@dylanfut2322?si=ujxpJ9Wj_I8IDr5c",
        "CANAL FRYKKO" to "https://youtube.com/@frykko57?si=QygSlJB8722jEyET"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = this
        L.load(this)
        val root = FrameLayout(this)
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.menu_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, FrameLayout.LayoutParams(-1, -1))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), 0, dp(28), dp(24))
        }
        root.addView(ScrollView(this).apply { addView(content) }, FrameLayout.LayoutParams(-1, -1).apply {
            topMargin = (resources.displayMetrics.heightPixels * 0.36f).toInt()
        })
        setContentView(root)
        if (L.lang.isEmpty()) showLang() else showHome()
    }

    override fun onDestroy() {
        if (current === this) current = null
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (screen == "home") showHome()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (screen == "home" || (screen == "lang" && L.lang.isEmpty())) super.onBackPressed() else showHome()
    }

    private fun goldButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(IVORY)
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#E6000000"))
            cornerRadius = dp(14).toFloat()
            setStroke(dp(2), GOLD)
        }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54)).apply { topMargin = dp(10) }
        setOnClickListener { action() }
    }

    private fun box() = GradientDrawable().apply {
        setColor(Color.parseColor("#D9000000"))
        cornerRadius = dp(12).toFloat()
        setStroke(dp(1), GOLD)
    }

    private fun infoBox(text: String) = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(IVORY)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = box()
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
    }

    private fun label(text: String, color: Int = IVORY, size: Float = 15f) = TextView(this).apply {
        this.text = text; textSize = size; gravity = Gravity.CENTER; setTextColor(color)
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun showLang() {
        screen = "lang"
        content.removeAllViews()
        content.addView(label("Elegí tu idioma / Choose your language", GOLD, 18f))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) }
        }
        fun flag(emoji: String, name: String, code: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = box()
            addView(label(emoji, IVORY, 54f))
            addView(label(name, IVORY, 15f))
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(10), 0, dp(10), 0) }
            setOnClickListener {
                L.set(this@MainActivity, code)
                ClickerService.instance?.refreshTexts()
                showHome()
            }
        }
        row.addView(flag("🇺🇸", "English", "en"))
        row.addView(flag("🇦🇷", "Español", "es"))
        content.addView(row)
        content.addView(infoBox("ES: Tocá una bandera para elegir el idioma de la app.\nEN: Tap a flag to choose the app language."))
    }

    private fun showHome() {
        screen = "home"
        content.removeAllViews()
        val s = ClickerService.instance
        val st = when {
            s == null -> L.t("status_off")
            !s.overlayShown -> L.t("status_hidden")
            else -> L.t("status_on") + s.packs
        }
        content.addView(label(st, if (s == null) RED else GREEN))
        content.addView(goldButton(L.t("btn_activate")) {
            val svc = ClickerService.instance
            if (svc == null) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            else { svc.showOverlay(); toast(L.t("panel_shown")); showHome() }
        })
        content.addView(goldButton(L.t("btn_reset")) {
            val svc = ClickerService.instance
            if (svc == null) toast(L.t("need_service")) else { svc.resetPositions(); toast(L.t("reset_done")) }
        })
        content.addView(goldButton("▶️ " + L.t("btn_channels")) { showChannels() })
        content.addView(goldButton(L.t("btn_lang")) { showLang() })
        content.addView(infoBox(L.t("home_info")))
    }

    private fun showChannels() {
        screen = "channels"
        content.removeAllViews()
        content.addView(label(L.t("btn_channels"), GOLD, 20f))
        content.addView(infoBox(L.t("ch_info")))
        for ((name, url) in channels) {
            content.addView(goldButton(name) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { toast(url) }
            })
        }
        content.addView(goldButton(L.t("back")) { showHome() })
    }
}
