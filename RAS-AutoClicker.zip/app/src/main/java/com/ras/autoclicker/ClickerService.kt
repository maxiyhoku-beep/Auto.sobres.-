package com.ras.autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.text.Normalizer

class ClickerService : AccessibilityService() {

    companion object { var instance: ClickerService? = null }

    private val GOLD = Color.parseColor("#D4AF37")
    private val IVORY = Color.parseColor("#F5F0E1")
    private val EMERALD = Color.parseColor("#2ECC71")
    private val RED = Color.parseColor("#E53935")
    private val WHITE = Color.parseColor("#FFFFFF")

    // Claves de punteros y posiciones por defecto (fracción de pantalla, medidas en tus capturas)
    private val keys = listOf("sa", "sm", "save", "n", "s", "b", "ok")
    private val defaults = mapOf(
        "sa" to floatArrayOf(0.257f, 0.720f),    // SELL ALL
        "sm" to floatArrayOf(0.499f, 0.720f),    // SELL DUPLICATES
        "save" to floatArrayOf(0.740f, 0.720f),  // SAVE ALL
        "n" to floatArrayOf(0.619f, 0.720f),     // NEXT PACK
        "s" to floatArrayOf(0.500f, 0.721f),     // SKIP
        "b" to floatArrayOf(0.583f, 0.505f),     // BONUS: botón de la izquierda (OK)
        "ok" to floatArrayOf(0.268f, 0.505f)     // BONUS: botón de la izquierda, punto exacto
    )

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val prefs by lazy { getSharedPreferences("rasc", MODE_PRIVATE) }
    private val views = HashMap<String, View>()

    private lateinit var panel: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var eyeBtn: TextView
    private lateinit var saBtn: TextView
    private lateinit var smBtn: TextView
    private lateinit var info: TextView

    // Ajustes finos para que funcione en la mayor cantidad de celulares
    private var alphaSlow = 0            // pruebas extra en pantallas que tardan en pintar el botón
    private var tapLenMs = 60L          // duración del toque (algunos celulares ignoran toques muy cortos)
    private var actionWaitMs = 550L     // espera entre el botón de venta y NEXT PACK
    private var gapMs = 150L            // espera después de tocar NEXT PACK

    var running = false
        private set
    var packs = 0
        private set
    var overlayShown = true
        private set
    private var hidden = false
    private var sizePx = 0

    // modo guardado: "sa", "sm" o "save"
    private var modeName: String
        get() = prefs.getString("mode", "save") ?: "save"
        set(v) { prefs.edit().putString("mode", v).apply() }

    // Estado del ciclo
    private var gen = 0
    private var busy = false
    private var lastProgress = 0L
    private var lastShot = 0L
    private var lastTapKey = ""
    private var lastTapAt = 0L
    private var lastKnown = 0L
    private var lastOcr = 0L
    private var pendingScreen = ""
    private var secondSkip = 0
    private var lastSkipTap = 0L
    private var runStart = 0L
    private var accumulated = 0L

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun now() = SystemClock.uptimeMillis()
    private fun screenW() = wm.currentWindowMetrics.bounds.width()
    private fun screenH() = wm.currentWindowMetrics.bounds.height()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun overlayParams(w: Int, h: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun ring(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT); setStroke(dp(3), color)
    }

    private fun oval(fill: Int, stroke: Int?) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(fill); if (stroke != null) setStroke(dp(2), stroke)
    }

    private fun colorOf(k: String) = when (k) { "n" -> EMERALD; "s" -> WHITE; "b", "ok" -> RED; else -> GOLD }

    /** Toques más largos en las marcas que suelen ignorar los gestos muy cortos. */
    private fun defaultTapLen(): Long {
        val m = android.os.Build.MANUFACTURER.lowercase()
        val mod = android.os.Build.MODEL.lowercase()
        return if (m.contains("samsung") || m.contains("xiaomi") || m.contains("redmi") ||
            m.contains("poco") || mod.contains("sm-")) 90L else 60L
    }

    override fun onServiceConnected() {
        instance = this
        L.load(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        sizePx = dp(40)
        // Valores por defecto según el celular, para que el toque no se pierda
        tapLenMs = prefs.getLong("tapLen", defaultTapLen()).toLong()
        actionWaitMs = prefs.getLong("actWait", 550L)
        gapMs = prefs.getLong("gap", 150L)
        // Los punteros son solo un anillo (centro transparente) para no tapar el botón que se analiza
        for (k in keys) {
            val p = overlayParams(sizePx, sizePx, 0, 0)
            val v = View(this).apply { background = ring(colorOf(k)) }
            makeDraggable(v, p) { savePos(k) }
            wm.addView(v, p)
            views[k] = v
            place(k)
        }
        buildPanel()
        applyVisibility()
        updatePanel()
    }

    // ---------- punteros ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun makeDraggable(v: View, p: WindowManager.LayoutParams, onDrop: () -> Unit) {
        var dx = 0f; var dy = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = p.x - e.rawX; dy = p.y - e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (e.rawX + dx).toInt(); p.y = (e.rawY + dy).toInt(); moved = true
                    wm.updateViewLayout(v, p)
                }
                MotionEvent.ACTION_UP -> if (moved) onDrop() else v.performClick()
            }
            true
        }
    }

    private fun place(k: String) {
        val v = views[k] ?: return
        val p = v.layoutParams as WindowManager.LayoutParams
        val d = defaults[k]!!
        p.x = (prefs.getFloat("x_$k", d[0]) * screenW()).toInt() - sizePx / 2
        p.y = (prefs.getFloat("y_$k", d[1]) * screenH()).toInt() - sizePx / 2
        wm.updateViewLayout(v, p)
    }

    /** Centro del puntero en coordenadas de pantalla (sale de lo guardado, sirve aunque esté oculto). */
    private fun pos(k: String): IntArray {
        val v = views[k]!!
        val p = v.layoutParams as WindowManager.LayoutParams
        return intArrayOf(p.x + sizePx / 2, p.y + sizePx / 2)
    }

    private fun savePos(k: String) {
        val c = pos(k)
        prefs.edit().putFloat("x_$k", c[0].toFloat() / screenW()).putFloat("y_$k", c[1].toFloat() / screenH()).apply()
    }

    fun resetPositions() {
        val e = prefs.edit()
        for (k in keys) e.remove("x_$k").remove("y_$k")
        e.apply()
        for (k in keys) place(k)
    }

    private fun setTouchable(t: Boolean) {
        val base = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        for (v in views.values) {
            val p = v.layoutParams as WindowManager.LayoutParams
            p.flags = if (t) base else base or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(v, p)
        }
    }

    /** Solo se ve el puntero de acción del modo elegido, más N y S. */
    private fun applyVisibility() {
        for ((k, v) in views) {
            val used = k == "n" || k == "s" || k == "b" || k == "ok" || k == modeName
            v.visibility = when {
                !overlayShown || !used -> View.GONE
                hidden -> View.INVISIBLE
                else -> View.VISIBLE
            }
        }
        if (::panel.isInitialized) panel.visibility = if (overlayShown) View.VISIBLE else View.GONE
    }

    // ---------- panel ----------
    private fun roundBtn(label: String, size: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label; textSize = 16f; gravity = Gravity.CENTER; setTextColor(IVORY)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { leftMargin = dp(6) }
    }

    private fun buildPanel() {
        val p = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, dp(8), dp(90))
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E6000000")); cornerRadius = dp(28).toFloat(); setStroke(dp(2), GOLD)
            }
        }
        playBtn = roundBtn("▶", 44) { if (running) stop() else start() }.apply {
            textSize = 20f
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
        }
        eyeBtn = roundBtn("👁", 38) { togglePointers() }.apply { background = oval(Color.TRANSPARENT, GOLD) }
        val offBtn = roundBtn("⏻", 38) { closeOverlay() }.apply { background = oval(Color.TRANSPARENT, RED) }
        saBtn = roundBtn("SA", 38) { pickMode(if (modeName == "sa") "save" else "sa") }.apply { textSize = 13f }
        smBtn = roundBtn("SM", 38) { pickMode(if (modeName == "sm") "save" else "sm") }.apply { textSize = 13f }
        info = TextView(this).apply { textSize = 11f; setTextColor(IVORY); setPadding(dp(8), 0, 0, 0) }
        for (v in listOf(playBtn, eyeBtn, offBtn, saBtn, smBtn, info)) panel.addView(v)
        makeDraggable(panel, p) {}
        wm.addView(panel, p)
    }

    private fun pickMode(m: String) {
        modeName = m
        toast(L.t(when (m) { "sa" -> "m_sa"; "sm" -> "m_sm"; else -> "m_save" }))
        applyVisibility()
        updatePanel()
    }

    private fun updatePanel() {
        if (!::panel.isInitialized) return
        playBtn.text = if (running) "■" else "▶"
        playBtn.background = oval(if (running) RED else EMERALD, null)
        val extras = if (running) View.GONE else View.VISIBLE
        saBtn.visibility = extras; smBtn.visibility = extras
        saBtn.background = if (modeName == "sa") oval(GOLD, GOLD) else oval(Color.TRANSPARENT, GOLD)
        smBtn.background = if (modeName == "sm") oval(GOLD, GOLD) else oval(Color.TRANSPARENT, GOLD)
        saBtn.setTextColor(if (modeName == "sa") Color.BLACK else IVORY)
        smBtn.setTextColor(if (modeName == "sm") Color.BLACK else IVORY)
        eyeBtn.alpha = if (hidden) 0.45f else 1f
        updateInfo()
    }

    private fun elapsedMs(): Long = accumulated + if (running) now() - runStart else 0L

    private fun fmtTime(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }

    private fun updateInfo() {
        if (!::info.isInitialized) return
        val stats = "📦 " + packs + "  ⏱ " + fmtTime(elapsedMs())
        info.text = if (running) stats else L.t("p_paused") + "\n" + stats
    }

    fun refreshTexts() { L.load(this); updatePanel() }

    fun togglePointers() { hidden = !hidden; applyVisibility(); updatePanel() }

    fun showOverlay() { overlayShown = true; applyVisibility(); updatePanel() }

    /** Cierra panel y app sin quitar el permiso de Accesibilidad. */
    fun closeOverlay() {
        stop()
        overlayShown = false
        applyVisibility()
        MainActivity.current?.finishAndRemoveTask()
    }

    // ---------- ciclo ----------
    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            updateInfo()
            if (now() - lastProgress > 4000) restartLoop()   // anti-traba
            handler.postDelayed(this, 1000)
        }
    }

    private fun start() {
        running = true
        gen++
        busy = false
        lastProgress = now(); lastKnown = now()
        lastTapKey = ""; pendingScreen = ""
        secondSkip = 0; lastSkipTap = 0L
        runStart = now()
        setTouchable(false)
        updatePanel()
        handler.post { step(gen) }
        handler.postDelayed(ticker, 1000)
    }

    private fun stop() {
        if (running) accumulated += now() - runStart
        running = false
        gen++
        busy = false
        handler.removeCallbacksAndMessages(null)
        if (::panel.isInitialized) { setTouchable(true); updatePanel() }
    }

    private fun restartLoop() {
        gen++
        busy = false
        lastProgress = now()
        val g = gen
        handler.postDelayed({ step(g) }, 150)
    }

    private fun next(ms: Long) {
        if (!running) return
        busy = false
        lastProgress = now()
        val g = gen
        handler.postDelayed({ step(g) }, ms)
    }

    private fun step(g: Int) {
        if (!running || g != gen || busy) return
        val wait = 340 - (now() - lastShot)
        if (wait > 0) { handler.postDelayed({ step(g) }, wait); return }
        busy = true
        lastShot = now()
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    if (g != gen) { try { r.hardwareBuffer.close() } catch (e: Exception) {}; return }
                    var bmp: Bitmap? = null
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                        bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                    } catch (e: Throwable) {
                    } finally {
                        try { r.hardwareBuffer.close() } catch (e: Exception) {}
                    }
                    val b = bmp
                    if (b == null) { next(400); return }
                    try { analyze(b, g) } catch (e: Throwable) { b.recycle(); next(400) }
                }
                override fun onFailure(errorCode: Int) { if (g == gen) next(450) }
            })
        } catch (e: Throwable) {
            next(500)
        }
    }

    /**
     * ¿Hay un botón en ese punto? Los botones del juego son claros (celeste/lila casi blanco)
     * y parejos. No se lee el texto: funciona igual en cualquier idioma.
     */
    private fun buttonAt(bmp: Bitmap, k: String): Boolean {
        val c = pos(k)
        val r = dp(7)
        var total = 0; var light = 0
        var y = c[1] - r
        while (y <= c[1] + r) {
            var x = c[0] - r
            while (x <= c[0] + r) {
                if (x in 0 until bmp.width && y in 0 until bmp.height) {
                    val p = bmp.getPixel(x, y)
                    val mn = minOf(Color.red(p), Color.green(p), Color.blue(p))
                    val mx = maxOf(Color.red(p), Color.green(p), Color.blue(p))
                    total++
                    if (mn > 175 && mx - mn < 80) light++
                }
                x += 2
            }
            y += 2
        }
        // Círculos claros son "botones" con el 55%; en pantallas que tardan en pintarlo se baja a 40%
        val need = if (alphaSlow > 0) 40 else 55
        val ok = total > 0 && light * 100 / total >= need

        // Sensibilidad de emergencia: si en dos ciclos seguidos no se ve nada, lo intenta más suave
        if (ok) alphaSlow = 0
        return ok
    }

    private fun analyze(bmp: Bitmap, g: Int) {
        if (!running || g != gen) { bmp.recycle(); return }

        // El segundo SKIP se hace cuando el botón ya desapareció (o a los 650 ms, lo que pase primero)
        if (secondSkip == gen) {
            val stillThere = buttonAt(bmp, "s")
            if (!stillThere || now() - lastSkipTap >= 650) {
                secondSkip = 0
                bmp.recycle()
                tapKey("s")
                updateInfo()
                next(1200)
                return
            }
            bmp.recycle()
            next(120)
            return
        }

        val onSa = buttonAt(bmp, "sa")
        val onSave = buttonAt(bmp, "save")
        val onMode = buttonAt(bmp, modeName)
        val onN = buttonAt(bmp, "n")
        val onS = buttonAt(bmp, "s")

        // BONUS: hay un botón debajo del punto medio entre OK y GO TO CARDS: uno u otro,
        // nunca los dos. Si aparece uno, el otro está vacío.
        val onBonus = (buttonAt(bmp, "b") || buttonAt(bmp, "ok")) && !bothBonusButtons(bmp)

        // Qué pantalla es, según qué botones existen (no según lo que dicen)
        val screen = when {
            onSa && onSave && onMode -> "result"        // SELL ALL · SELL DUPLICATES · SAVE ALL
            onN && !onSa && !onSave -> "next"           // MY CARDS · NEXT PACK
            onS && !onN && !onSa && !onSave -> "skip"   // animación con SKIP
            onBonus -> "bonus"                          // BONUS: OK o GO TO CARDS
            else -> ""
        }

        if (screen.isEmpty()) {
            // No hay ningún botón conocido: sigue el ciclo
            if (now() - lastOcr > 1000 && now() - lastKnown > 1200) {
                lastOcr = now()
                checkBonus(bmp, g)
            } else {
                bmp.recycle(); next(250)
            }
            return
        }
        bmp.recycle()
        lastKnown = now()

        // Confirmación en 2 capturas seguidas para no tocar en mitad de una animación
        if (pendingScreen != screen) { pendingScreen = screen; next(120); return }
        pendingScreen = ""

        // BONUS: se toca el botón que esté (OK o GO TO CARDS) en el lado donde apareció
        if (screen == "bonus") {
            val key = if (buttonAt(bmp, "ok")) "ok" else "b"
            if (key == lastTapKey && now() - lastTapAt < 1500) { bmp.recycle(); next(300); return }
            bmp.recycle()
            tapKey(key)
            next(900)
            return
        }

        val key = when (screen) { "result" -> modeName; "next" -> "n"; else -> "s" }

        if (key != "s") secondSkip = 0

        // Evita doble toque del mismo botón (más corto que antes: en pantallas rápidas 1,8 s sobraba)
        if (key != "s" && key == lastTapKey && now() - lastTapAt < actionWaitMs) { next(250); return }

        tapKey(key)
        if (key == "n") packs++
        updateInfo()
        if (key == "s") {
            // Primer SKIP: queda armado el segundo, que se dispara al desaparecer el botón (máx. 650 ms)
            secondSkip = gen
            next(120)
        } else {
            // Igual en todos los celulares: no espera a leer el texto del botón
            next(if (key == "n") gapMs else actionWaitMs)
        }
    }

    /** ¿Hay botón en los dos lados a la vez? Entonces no es la pantalla del bonus. */
    private fun bothBonusButtons(bmp: Bitmap): Boolean {
        val left = buttonAt(bmp, "ok")
        val right = buttonAt(bmp, "b")
        return left && right
    }

    private fun norm(s: String): String =
        Normalizer.normalize(s.uppercase(), Normalizer.Form.NFD).filter { it in 'A'..'Z' }

    private fun checkBonus(bmp: Bitmap, g: Int) {
        try {
            recognizer.process(InputImage.fromBitmap(bmp, 0))
                .addOnSuccessListener { t ->
                    bmp.recycle()
                    if (!running || g != gen) return@addOnSuccessListener
                    val lines = t.textBlocks.flatMap { it.lines }
                    val els = lines.flatMap { it.elements }
                    if (lines.any { val n = norm(it.text); n == "BONUS" || n == "BONO" }) {
                        val ok = setOf("OK", "ACEPTAR", "OKAY")
                        val box = lines.firstOrNull { norm(it.text) in ok }?.boundingBox
                            ?: els.firstOrNull { norm(it.text) in ok }?.boundingBox
                        if (box != null) {
                            tap(box.exactCenterX(), box.exactCenterY())
                            lastKnown = now()
                            next(800); return@addOnSuccessListener
                        }
                    }
                    next(250)
                }
                .addOnFailureListener { bmp.recycle(); if (g == gen) next(400) }
        } catch (e: Throwable) {
            bmp.recycle(); next(400)
        }
    }

    private fun tapKey(k: String) {
        val c = pos(k)
        lastTapKey = k; lastTapAt = now()
        if (k == "s") lastSkipTap = now()
        val v = views[k]
        if (v != null && v.visibility == View.VISIBLE) {
            v.background = ring(RED)
            handler.postDelayed({ v.background = ring(colorOf(k)) }, 300)
        }
        tap(c[0].toFloat(), c[1].toFloat())
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val gd = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, tapLenMs))
            .build()
        // Si el gesto no se acepta, se reintenta una vez y, si tampoco, se toca más largo
        val ok = try { dispatchGesture(gd, null, null) } catch (e: Throwable) { false }
        if (!ok) {
            handler.postDelayed({
                val gd2 = GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(Path().apply { moveTo(x, y) }, 0, 300))
                    .build()
                try { dispatchGesture(gd2, null, null) } catch (e: Throwable) {}
            }, 200)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }

    override fun onDestroy() {
        stop()
        instance = null
        recognizer.close()
        super.onDestroy()
    }
}
