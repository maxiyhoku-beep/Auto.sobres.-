package com.ras.autoclicker

import android.content.Context

object L {
    var lang = ""

    fun load(c: Context) {
        lang = c.getSharedPreferences("rasc", Context.MODE_PRIVATE).getString("lang", "") ?: ""
    }

    fun set(c: Context, l: String) {
        lang = l
        c.getSharedPreferences("rasc", Context.MODE_PRIVATE).edit().putString("lang", l).apply()
    }

    fun t(k: String): String = (if (lang == "en") en else es)[k] ?: k

    private val es = mapOf(
        "status_off" to "● Servicio DESACTIVADO",
        "status_hidden" to "● Servicio activo · panel cerrado",
        "status_on" to "● Servicio activo · sobres: ",
        "btn_activate" to "Activar servicio / mostrar panel",
        "btn_reset" to "Reiniciar posición de punteros",
        "btn_channels" to "CANALES",
        "btn_lang" to "🌐 Idioma / Language",
        "home_info" to "MENÚ PRINCIPAL\nActivar servicio: la primera vez te lleva a Accesibilidad; después vuelve a mostrar el panel si lo cerraste.\nReiniciar punteros: vuelve todos los punteros a su lugar original.\n\nPANEL FLOTANTE\n▶ / ■  Iniciar o pausar el auto clicker.\n👁  Ocultar o mostrar los punteros (siguen funcionando aunque no se vean).\n⏻  Cerrar el panel y la app (el permiso queda activado).\nSA  SELL ALL: vende todas las cartas del sobre.\nSM  SELL MULTI: vende solo las repetidas.\nCon SA y SM apagados se guardan todas (SAVE ALL).\nMientras está en marcha solo se ven ■, 👁, ⏻, los sobres y el tiempo; SA y SM aparecen al pausar.\n\nPUNTEROS\nA (dorado): botón de acción del sobre. Según el modo va sobre SELL ALL, SELL DUPLICATES o SAVE ALL.\nN (verde): botón NEXT PACK / SIGUIENTE.\nS (blanco): botón SKIP / SALTAR de la animación.\nCada puntero toca cuando detecta que su botón apareció, sin leer el texto: funciona igual en cualquier idioma del juego.\nSe arrastran solo con el auto clicker pausado.\n\nEl bonus se cierra solo tocando OK.",
        "need_service" to "Primero activá el servicio",
        "reset_done" to "Punteros reiniciados",
        "panel_shown" to "Panel visible",
        "ch_info" to "CANALES\nTocá un canal para abrirlo en YouTube.",
        "back" to "← Volver",
        "p_paused" to "RAS · pausado",
        "m_sa" to "Modo SELL ALL: vende todas",
        "m_sm" to "Modo SELL MULTI: vende repetidas",
        "m_save" to "Modo SAVE ALL: guarda todas"
    )

    private val en = mapOf(
        "status_off" to "● Service OFF",
        "status_hidden" to "● Service on · panel closed",
        "status_on" to "● Service on · packs: ",
        "btn_activate" to "Enable service / show panel",
        "btn_reset" to "Reset pointer positions",
        "btn_channels" to "CHANNELS",
        "btn_lang" to "🌐 Idioma / Language",
        "home_info" to "MAIN MENU\nEnable service: the first time it opens Accessibility; afterwards it shows the panel again if you closed it.\nReset pointers: puts every pointer back in its original place.\n\nFLOATING PANEL\n▶ / ■  Start or pause the auto clicker.\n👁  Hide or show the pointers (they keep working while hidden).\n⏻  Close the panel and the app (the permission stays on).\nSA  SELL ALL: sells every card in the pack.\nSM  SELL MULTI: sells duplicates only.\nWith SA and SM off every card is kept (SAVE ALL).\nWhile running only ■, 👁, ⏻, packs and time are shown; SA and SM appear when paused.\n\nPOINTERS\nA (gold): pack action button. Depending on the mode it goes on SELL ALL, SELL DUPLICATES or SAVE ALL.\nN (green): NEXT PACK button.\nS (white): SKIP button of the animation.\nEach pointer taps when it detects its button appeared, without reading the text: it works the same in any game language.\nThey can only be dragged while paused.\n\nThe bonus is closed automatically by tapping OK.",
        "need_service" to "Enable the service first",
        "reset_done" to "Pointers reset",
        "panel_shown" to "Panel visible",
        "ch_info" to "CHANNELS\nTap a channel to open it on YouTube.",
        "back" to "← Back",
        "p_paused" to "RAS · paused",
        "m_sa" to "SELL ALL mode: sells everything",
        "m_sm" to "SELL MULTI mode: sells duplicates",
        "m_save" to "SAVE ALL mode: keeps everything"
    )
}
